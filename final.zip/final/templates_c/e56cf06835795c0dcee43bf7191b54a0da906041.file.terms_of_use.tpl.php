<?php /* Smarty version Smarty-3.1.15, created on 2016-06-07 03:50:45
         compiled from "C:\wamp\www\Overview\proto\templates\users\terms_of_use.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2573557562875b3a746-21389284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e56cf06835795c0dcee43bf7191b54a0da906041' => 
    array (
      0 => 'C:\\wamp\\www\\Overview\\proto\\templates\\users\\terms_of_use.tpl',
      1 => 1465264232,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2573557562875b3a746-21389284',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57562875ef0031_84062973',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57562875ef0031_84062973')) {function content_57562875ef0031_84062973($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ('common/status_messages.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="container">
  <div class="col-md-12">
    <hgroup class="mb20">
      <br>
      <h1><span class="glyphicon glyphicon-duplicate"></span> Termos de Uso</h1>
    </hgroup>
  </div>

  <div class="tab-content col-md-12">
    <p>O conteúdo do site Overview é propriedade do grupo lbaw1566 . Como “conteúdo do site” entenda-se textos, imagens, logótipos, fotos, ilustrações, material de vídeo e áudio, webdesign e software, entre outros. A proteção dos direitos de autor dos conteúdos do site Overview estende-se a todas as reproduções ou cópias obtidas a partir do seu conteúdo.</p>
    <p>O utilizador está autorizado a fazer uso dos conteúdos para fins estritamente pessoais, sendo-lhe expressamente proibido publicar, reproduzir, difundir, distribuir ou, por qualquer outra forma, tornar os conteúdos acessíveis a terceiros, para fins de comunicação pública ou de comercialização, online ou em cópias de papel, sem autorização expressa.</p>
    <p>Rejeita-se qualquer responsabilidade por qualquer uso indevido do site por terceiros.</p>
    <p>Parte-se do princípio de que os utilizadores deste site conhecem perfeitamente as características, os constrangimentos, limitações e defeitos da Internet, aceitando correr os riscos inerentes a que está sujeito.</p>
    <p>Todo o conteúdo informativo presente no Overview foi incluído de boa fé e serve exclusivamente para informação dos utilizadores, sendo a sua utilização da sua exclusiva responsabilidade.</p>
    <p>Sem prejuízo do cumprimento da proteção de dados pessoais, reserva-se o direito de realizar alterações e correções, suspender, interromper ou encerrar o site quando o considerar apropriado, sem necessidade de pré-aviso e pelo período que entender necessário, por quaisquer razões de ordem técnica, administrativa, de força maior ou outra.</p>
    <p>O utilizador deste site obriga-se a respeitar a legislação aplicável, nomeadamente, o Código do Direito de Autor e dos Direitos Conexos, o Código da Propriedade Industrial e a Lei da Criminalidade Informática, bem como a agir de boa-fé e a fazer uma utilização do site que não ofenda quaisquer direitos de terceiros, nomeadamente que não constitua qualquer ataque em função de nacionalidade, origem étnica, religião, convicção política ou sexo, que não constitua difamação, incitação ao furto, fraude, violência, terrorismo, sadismo, prostituição, pedofilia, bem como que não empregue conteúdos de carácter obsceno, indecoroso ou pornográfico.</p>
  </div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
