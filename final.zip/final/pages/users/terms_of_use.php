<?php
  include_once('../../config/init.php'); 
      
  $smarty->display('users/terms_of_use.tpl'); 
?>