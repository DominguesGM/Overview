 $("#images-upload").fileinput({
       language: 'pt',
       maxFileSize: 10000,
       maxFileCount: 20,
       showRemove: true,
       allowedFileExtensions: ["jpg", "png"]
   });