<?php
  include_once('../config/init.php');
  //include_once($BASE_DIR .'database/articles.php');
  
  $smarty->display('main.tpl');
?>