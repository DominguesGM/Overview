<?php /* Smarty version Smarty-3.1.15, created on 2016-04-28 01:48:28
         compiled from "C:\wamp\www\Overview\proto\templates\common\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1097157214fcc649c84-58235758%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3206c49c9359636dfba63eabe9213c2dd1be9902' => 
    array (
      0 => 'C:\\wamp\\www\\Overview\\proto\\templates\\common\\footer.tpl',
      1 => 1461706628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1097157214fcc649c84-58235758',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57214fcc8f1180_90351341',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57214fcc8f1180_90351341')) {function content_57214fcc8f1180_90351341($_smarty_tpl) {?></div>
<hr>

<!-- Footer -->
<footer>
    <div class="row">
        <div class="col-lg-12">
                <p>Copyright &copy; Overview 2016</p>
        </div>
    </div>
    <!-- /.row -->
</footer>

</div>
<!-- /.container -->
</div>
</div>

<!-- browse_button Script -->
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/browse_button.js"></script>

<!-- jQuery -->
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/bootstrap.min.js"></script>

<!-- Header and Sidebar Script -->
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/main-template.js"></script>

<!-- Register Script -->
<script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/register.js"></script>

</body>

</html>
<?php }} ?>
