<?php /* Smarty version Smarty-3.1.15, created on 2016-04-28 03:12:07
         compiled from "C:\wamp\www\Overview\proto\templates\main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32107572160039cce45-02006968%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6e4729f929d2809f410c0e34e7efe733dee94579' => 
    array (
      0 => 'C:\\wamp\\www\\Overview\\proto\\templates\\main.tpl',
      1 => 1461805919,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32107572160039cce45-02006968',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57216003afd856_07099539',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57216003afd856_07099539')) {function content_57216003afd856_07099539($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


    <!-- Projects Row -->
    <div class="row news-row">
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Trending</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>First Piece</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Trending Piece</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">World</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>Danger in the Middle East</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Important World News</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Europe</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>Grexit: is it over yet?</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Will Great Britain stay in Europe</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->

    <!-- Projects Row -->
    <div class="row news-row">
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Economy</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>It's all crumbling down</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Take up loans, it's good practice</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Sports</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>Leichester wins to BarclaysPL</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Local team beats top tier team</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Culture</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>Best movies so far this year</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>Bands you should listen to</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Projects Row -->
    <div class="row news-row">
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Category</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>News Article</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>News Article</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 portfolio-item short_news_item">
            <h2 class="main_category"><a href="#">Category</a></h2>
            <div class="short_category_content">
                <div class="short_category_item">
                    <a href="#"><h3>News Article</h3></a>
                    <span class="image-box" data-score="321"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
                <div class="short_category_item">
                    <a href="#"><h3>News Article</h3></a>
                    <span class="image-box" data-score="123"><img class="img-thumbnail" src="http://placehold.it/75x75" alt=""></span>
                    <p class="summary">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et est in tellus fringilla fringilla id eu tellus. Quisque dapibus tristique hendrerit cras amet.</p>
                </div>
            </div>
        </div>

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
