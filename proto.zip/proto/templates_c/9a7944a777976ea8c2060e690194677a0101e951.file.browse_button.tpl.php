<?php /* Smarty version Smarty-3.1.15, created on 2016-04-28 01:48:28
         compiled from "C:\wamp\www\Overview\proto\templates\common\browse_button.tpl" */ ?>
<?php /*%%SmartyHeaderCode:612257214fcc498866-68205908%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9a7944a777976ea8c2060e690194677a0101e951' => 
    array (
      0 => 'C:\\wamp\\www\\Overview\\proto\\templates\\common\\browse_button.tpl',
      1 => 1461697123,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '612257214fcc498866-68205908',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57214fcc527c33_04675431',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57214fcc527c33_04675431')) {function content_57214fcc527c33_04675431($_smarty_tpl) {?><div class="input-group">
  <span class="input-group-btn">
    <span class="btn btn-primary btn-file">
      Procurar&hellip; <input name="photo" type="file">
    </span>
    <br>
  </span>
  <input type="text" class="form-control" readonly>
</div>
<?php }} ?>
